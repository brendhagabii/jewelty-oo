package joalheria.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Compra {
    private int id;
    private Cliente cliente;
    private LocalDate data_compra;

    public Compra(Cliente cliente, LocalDate data_compra) {
        this.cliente = cliente;
        this.data_compra = data_compra;
    }

    public Compra(int id, Cliente cliente, LocalDate data_compra) {
        this.id = id;
        this.cliente = cliente;
        this.data_compra = data_compra;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public LocalDate getData_compra() {
        return data_compra;
    }

    public void setData_compra(LocalDate data_compra) {
        this.data_compra = data_compra;
    }

    @Override
    public String toString() {
        return "Compra Nº " + id + " - Data da Compra: " + data_compra.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    }
}
